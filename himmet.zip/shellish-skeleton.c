#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h> // termios, TCSANOW, ECHO, ICANON
#include <unistd.h>
const char *sysname = "shellish";

/**
 * Signal handler for SIGCHLD - reaps zombie background processes
 */
void sigchld_handler(int sig) {
  (void)sig;
  // Reap all finished child processes (non-blocking)
  while (waitpid(-1, NULL, WNOHANG) > 0)
    ;
}

enum return_codes {
  SUCCESS = 0,
  EXIT = 1,
  UNKNOWN = 2,
};

struct command_t {
  char *name;
  bool background;
  bool auto_complete;
  int arg_count;
  char **args;
  char *redirects[3];     // in/out redirection
  struct command_t *next; // for piping
};

/**
 * Prints a command struct
 * @param struct command_t *
 */
void print_command(struct command_t *command) {
  int i = 0;
  printf("Command: <%s>\n", command->name);
  printf("\tIs Background: %s\n", command->background ? "yes" : "no");
  printf("\tNeeds Auto-complete: %s\n", command->auto_complete ? "yes" : "no");
  printf("\tRedirects:\n");
  for (i = 0; i < 3; i++)
    printf("\t\t%d: %s\n", i,
           command->redirects[i] ? command->redirects[i] : "N/A");
  printf("\tArguments (%d):\n", command->arg_count);
  for (i = 0; i < command->arg_count; ++i)
    printf("\t\tArg %d: %s\n", i, command->args[i]);
  if (command->next) {
    printf("\tPiped to:\n");
    print_command(command->next);
  }
}

/**
 * Release allocated memory of a command
 * @param  command [description]
 * @return         [description]
 */
int free_command(struct command_t *command) {
  if (command->arg_count) {
    for (int i = 0; i < command->arg_count; ++i)
      free(command->args[i]);
    free(command->args);
  }
  for (int i = 0; i < 3; ++i)
    if (command->redirects[i])
      free(command->redirects[i]);
  if (command->next) {
    free_command(command->next);
    command->next = NULL;
  }
  free(command->name);
  free(command);
  return 0;
}

/**
 * Show the command prompt
 * @return [description]
 */
int show_prompt() {
  char cwd[1024], hostname[1024];
  gethostname(hostname, sizeof(hostname));
  getcwd(cwd, sizeof(cwd));
  printf("%s@%s:%s %s$ ", getenv("USER"), hostname, cwd, sysname);
  return 0;
}

/**
 * Parse a command string into a command struct
 * @param  buf     [description]
 * @param  command [description]
 * @return         0
 */
int parse_command(char *buf, struct command_t *command) {
  const char *splitters = " \t"; // split at whitespace
  int index, len;
  len = strlen(buf);
  while (len > 0 && strchr(splitters, buf[0]) != NULL) // trim left whitespace
  {
    buf++;
    len--;
  }
  while (len > 0 && strchr(splitters, buf[len - 1]) != NULL)
    buf[--len] = 0; // trim right whitespace

  if (len > 0 && buf[len - 1] == '?') // auto-complete
    command->auto_complete = true;
  if (len > 0 && buf[len - 1] == '&') // background
    command->background = true;

  char *pch = strtok(buf, splitters);
  if (pch == NULL) {
    command->name = (char *)malloc(1);
    command->name[0] = 0;
  } else {
    command->name = (char *)malloc(strlen(pch) + 1);
    strcpy(command->name, pch);
  }

  command->args = (char **)malloc(sizeof(char *));

  int redirect_index;
  int arg_index = 0;
  char temp_buf[1024], *arg;
  while (1) {
    // tokenize input on splitters
    pch = strtok(NULL, splitters);
    if (!pch)
      break;
    arg = temp_buf;
    strcpy(arg, pch);
    len = strlen(arg);

    if (len == 0)
      continue; // empty arg, go for next
    while (len > 0 && strchr(splitters, arg[0]) != NULL) // trim left whitespace
    {
      arg++;
      len--;
    }
    while (len > 0 && strchr(splitters, arg[len - 1]) != NULL)
      arg[--len] = 0; // trim right whitespace
    if (len == 0)
      continue; // empty arg, go for next

    // piping to another command
    if (strcmp(arg, "|") == 0) {
      struct command_t *c =
          (struct command_t *)malloc(sizeof(struct command_t));
      int l = strlen(pch);
      pch[l] = splitters[0]; // restore strtok termination
      index = 1;
      while (pch[index] == ' ' || pch[index] == '\t')
        index++; // skip whitespaces

      parse_command(pch + index, c);
      pch[l] = 0; // put back strtok termination
      command->next = c;
      continue;
    }

    // background process
    if (strcmp(arg, "&") == 0)
      continue; // handled before

    // handle input redirection
    redirect_index = -1;
    if (arg[0] == '<')
      redirect_index = 0;
    if (arg[0] == '>') {
      if (len > 1 && arg[1] == '>') {
        redirect_index = 2;
        arg++;
        len--;
      } else
        redirect_index = 1;
    }
    if (redirect_index != -1) {
      command->redirects[redirect_index] = (char *)malloc(len);
      strcpy(command->redirects[redirect_index], arg + 1);
      continue;
    }

    // normal arguments
    if (len > 2 &&
        ((arg[0] == '"' && arg[len - 1] == '"') ||
         (arg[0] == '\'' && arg[len - 1] == '\''))) // quote wrapped arg
    {
      arg[--len] = 0;
      arg++;
    }
    command->args =
        (char **)realloc(command->args, sizeof(char *) * (arg_index + 1));
    command->args[arg_index] = (char *)malloc(len + 1);
    strcpy(command->args[arg_index++], arg);
  }
  command->arg_count = arg_index;

  // increase args size by 2
  command->args = (char **)realloc(command->args,
                                   sizeof(char *) * (command->arg_count += 2));

  // shift everything forward by 1
  for (int i = command->arg_count - 2; i > 0; --i)
    command->args[i] = command->args[i - 1];

  // set args[0] as a copy of name
  command->args[0] = strdup(command->name);
  // set args[arg_count-1] (last) to NULL
  command->args[command->arg_count - 1] = NULL;

  return 0;
}

void prompt_backspace() {
  putchar(8);   // go back 1
  putchar(' '); // write empty over
  putchar(8);   // go back 1 again
}

/**
 * Prompt a command from the user
 * @param  buf      [description]
 * @param  buf_size [description]
 * @return          [description]
 */
int prompt(struct command_t *command) {
  int index = 0;
  char c;
  char buf[4096];
  static char oldbuf[4096];

  // tcgetattr gets the parameters of the current terminal
  // STDIN_FILENO will tell tcgetattr that it should write the settings
  // of stdin to oldt
  static struct termios backup_termios, new_termios;
  tcgetattr(STDIN_FILENO, &backup_termios);
  new_termios = backup_termios;
  // ICANON normally takes care that one line at a time will be processed
  // that means it will return if it sees a "\n" or an EOF or an EOL
  new_termios.c_lflag &=
      ~(ICANON |
        ECHO); // Also disable automatic echo. We manually echo each char.
  // Those new settings will be set to STDIN
  // TCSANOW tells tcsetattr to change attributes immediately.
  tcsetattr(STDIN_FILENO, TCSANOW, &new_termios);

  show_prompt();
  buf[0] = 0;
  while (1) {
    c = getchar();
    // printf("Keycode: %u\n", c); // DEBUG: uncomment for debugging

    if (c == 9) // handle tab
    {
      buf[index++] = '?'; // autocomplete
      break;
    }

    if (c == 127) // handle backspace
    {
      if (index > 0) {
        prompt_backspace();
        index--;
      }
      continue;
    }

    if (c == 27 || c == 91 || c == 66 || c == 67 || c == 68) {
      continue;
    }

    if (c == 65) // up arrow
    {
      while (index > 0) {
        prompt_backspace();
        index--;
      }

      char tmpbuf[4096];
      printf("%s", oldbuf);
      strcpy(tmpbuf, buf);
      strcpy(buf, oldbuf);
      strcpy(oldbuf, tmpbuf);
      index += strlen(buf);
      continue;
    }

    putchar(c); // echo the character
    buf[index++] = c;
    if (index >= sizeof(buf) - 1)
      break;
    if (c == '\n') // enter key
      break;
    if (c == 4) // Ctrl+D
      return EXIT;
  }
  if (index > 0 && buf[index - 1] == '\n') // trim newline from the end
    index--;
  buf[index++] = '\0'; // null terminate string

  strcpy(oldbuf, buf);

  parse_command(buf, command);

  // print_command(command); // DEBUG: uncomment for debugging

  // restore the old settings
  tcsetattr(STDIN_FILENO, TCSANOW, &backup_termios);
  return SUCCESS;
}

/**
 * Resolve the full path of a command by searching through PATH directories.
 * If the command already contains a '/', it is treated as a direct path.
 * Otherwise, each directory in the PATH environment variable is checked.
 *
 * @param  command_name  the name of the command to resolve
 * @param  resolved_path buffer to store the resolved full path
 * @param  buf_size      size of the resolved_path buffer
 * @return               0 on success, -1 if the command was not found
 */
int resolve_path(const char *command_name, char *resolved_path, size_t buf_size) {
  // If the command contains a '/', treat it as a direct/relative path
  if (strchr(command_name, '/') != NULL) {
    strncpy(resolved_path, command_name, buf_size);
    resolved_path[buf_size - 1] = '\0';
    if (access(resolved_path, X_OK) == 0)
      return 0;
    return -1;
  }

  // Get the PATH environment variable
  char *path_env = getenv("PATH");
  if (path_env == NULL)
    return -1;

  // Make a mutable copy since strtok modifies the string
  char *path_copy = strdup(path_env);
  if (path_copy == NULL)
    return -1;

  char *dir = strtok(path_copy, ":");
  while (dir != NULL) {
    snprintf(resolved_path, buf_size, "%s/%s", dir, command_name);
    if (access(resolved_path, X_OK) == 0) {
      free(path_copy);
      return 0; // found it
    }
    dir = strtok(NULL, ":");
  }

  free(path_copy);
  return -1; // not found
}

/**
 * Set up I/O redirections for the child process using dup2().
 * redirects[0] = input file  (<)
 * redirects[1] = output file (>, truncate)
 * redirects[2] = append file (>>)
 */
void setup_redirections(struct command_t *command) {
  // Input redirection: <inputfile
  if (command->redirects[0]) {
    int fd = open(command->redirects[0], O_RDONLY);
    if (fd < 0) {
      perror(command->redirects[0]);
      exit(1);
    }
    dup2(fd, STDIN_FILENO);
    close(fd);
  }
  // Output redirection: >outputfile (truncate)
  if (command->redirects[1]) {
    int fd = open(command->redirects[1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
      perror(command->redirects[1]);
      exit(1);
    }
    dup2(fd, STDOUT_FILENO);
    close(fd);
  }
  // Append redirection: >>appendfile
  if (command->redirects[2]) {
    int fd = open(command->redirects[2], O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd < 0) {
      perror(command->redirects[2]);
      exit(1);
    }
    dup2(fd, STDOUT_FILENO);
    close(fd);
  }
}

// Forward declarations for builtin commands
int builtin_cut(struct command_t *command);

// Execute a single command (used by both simple and piped execution).
// Resolves the path and calls execv(). Does not return on success.
// Also handles builtin commands so they work inside pipelines.
void exec_command(struct command_t *command) {
  // Handle builtin commands inside pipelines too
  if (strcmp(command->name, "cut") == 0) {
    builtin_cut(command);
    exit(0);
  }

  char resolved_path[1024];
  if (resolve_path(command->name, resolved_path, sizeof(resolved_path)) != 0) {
    printf("-%s: %s: command not found\n", sysname, command->name);
    exit(127);
  }
  execv(resolved_path, command->args);
  printf("-%s: %s: %s\n", sysname, command->name, strerror(errno));
  exit(127);
}

// Execute a pipeline of commands recursively.
// Each command in the chain is connected via pipes.
void exec_pipeline(struct command_t *command) {
  if (command->next == NULL) {
    // Last (or only) command in the pipeline
    setup_redirections(command);
    exec_command(command);
    return;
  }

  // Create a pipe: pipefd[0]=read end, pipefd[1]=write end
  int pipefd[2];
  if (pipe(pipefd) == -1) {
    perror("pipe");
    exit(1);
  }

  pid_t pid = fork();
  if (pid == 0) {
    // Child: runs the current command, writes to pipe
    close(pipefd[0]); // close unused read end
    dup2(pipefd[1], STDOUT_FILENO); // stdout -> pipe write end
    close(pipefd[1]);
    setup_redirections(command);
    exec_command(command);
  } else {
    // Parent: continues with the next command, reads from pipe
    close(pipefd[1]); // close unused write end
    dup2(pipefd[0], STDIN_FILENO); // stdin -> pipe read end
    close(pipefd[0]);
    waitpid(pid, NULL, 0);
    exec_pipeline(command->next); // recurse for next command
  }
}

// ============================================================
// PART III: Builtin Commands
// ============================================================

// (a) cut command: reads from stdin, prints specified fields
// Supports -d (delimiter) and -f (fields) options
int builtin_cut(struct command_t *command) {
  char delimiter = '\t'; // default delimiter is TAB
  char *fields_str = NULL;

  // Parse arguments: -d <delim> and -f <fields>
  for (int i = 1; i < command->arg_count - 1; i++) {
    if (command->args[i] == NULL) break;
    if ((strcmp(command->args[i], "-d") == 0 || strcmp(command->args[i], "--delimiter") == 0)
        && i + 1 < command->arg_count - 1) {
      // Next arg is the delimiter character
      delimiter = command->args[i + 1][0];
      i++; // skip next arg
    } else if ((strcmp(command->args[i], "-f") == 0 || strcmp(command->args[i], "--fields") == 0)
               && i + 1 < command->arg_count - 1) {
      fields_str = command->args[i + 1];
      i++; // skip next arg
    }
  }

  if (fields_str == NULL) {
    fprintf(stderr, "cut: you must specify a list of fields with -f\n");
    return SUCCESS;
  }

  // Parse the field indices from comma-separated string (e.g., "1,3,10")
  int fields[64];
  int field_count = 0;
  char *fields_copy = strdup(fields_str);
  char *tok = strtok(fields_copy, ",");
  while (tok != NULL && field_count < 64) {
    fields[field_count++] = atoi(tok);
    tok = strtok(NULL, ",");
  }
  free(fields_copy);

  // Read from stdin line by line and print selected fields
  char line[4096];
  while (fgets(line, sizeof(line), stdin) != NULL) {
    // Remove trailing newline
    size_t len = strlen(line);
    if (len > 0 && line[len - 1] == '\n')
      line[len - 1] = '\0';

    // Split line by delimiter into tokens
    char *tokens[256];
    int token_count = 0;
    char *line_copy = strdup(line);

    // Manual tokenization to handle empty fields
    char *start = line_copy;
    char *end;
    while ((end = strchr(start, delimiter)) != NULL && token_count < 256) {
      *end = '\0';
      tokens[token_count++] = start;
      start = end + 1;
    }
    if (token_count < 256)
      tokens[token_count++] = start; // last token

    // Print selected fields
    for (int i = 0; i < field_count; i++) {
      int idx = fields[i] - 1; // convert to 0-indexed
      if (i > 0) printf("%c", delimiter);
      if (idx >= 0 && idx < token_count)
        printf("%s", tokens[idx]);
    }
    printf("\n");
    free(line_copy);
  }

  return SUCCESS;
}

// (b) chatroom command: group chat using named pipes (FIFOs)
// Usage: chatroom <roomname> <username>
int builtin_chatroom(struct command_t *command) {
  if (command->arg_count < 3) {
    fprintf(stderr, "Usage: chatroom <roomname> <username>\n");
    return SUCCESS;
  }

  char *roomname = command->args[1];
  char *username = command->args[2];

  // Create room directory: /tmp/chatroom-<roomname>/
  char room_path[512];
  snprintf(room_path, sizeof(room_path), "/tmp/chatroom-%s", roomname);
  mkdir(room_path, 0777);

  // Create user's named pipe: /tmp/chatroom-<roomname>/<username>
  char user_pipe_path[512];
  snprintf(user_pipe_path, sizeof(user_pipe_path), "%s/%s", room_path, username);
  mkfifo(user_pipe_path, 0666); // create named pipe (OK if already exists)

  printf("Welcome to %s!\n", roomname);

  // Fork a reader process that continuously reads from our named pipe
  pid_t reader_pid = fork();
  if (reader_pid == 0) {
    // Child: reader process - reads messages from our pipe and prints them
    while (1) {
      int fd = open(user_pipe_path, O_RDONLY);
      if (fd < 0) break;
      char buf[1024];
      ssize_t n;
      while ((n = read(fd, buf, sizeof(buf) - 1)) > 0) {
        buf[n] = '\0';
        printf("%s", buf);
        fflush(stdout);
      }
      close(fd);
    }
    exit(0);
  }

  // Parent: writer process - reads user input and writes to all other pipes
  char msg_buf[1024];
  while (1) {
    printf("[%s] %s > ", roomname, username);
    fflush(stdout);
    if (fgets(msg_buf, sizeof(msg_buf), stdin) == NULL)
      break;

    // Remove trailing newline
    size_t len = strlen(msg_buf);
    if (len > 0 && msg_buf[len - 1] == '\n')
      msg_buf[len - 1] = '\0';

    if (strlen(msg_buf) == 0)
      continue;

    // Exit chatroom with /exit command
    if (strcmp(msg_buf, "/exit") == 0) {
      printf("Leaving %s. Goodbye!\n", roomname);
      break;
    }

    // Format the message
    char formatted[1200];
    snprintf(formatted, sizeof(formatted), "[%s] %s: %s\n", roomname, username, msg_buf);

    // Send to all users in the room (write to each named pipe)
    DIR *dir = opendir(room_path);
    if (dir == NULL) {
      perror("opendir");
      continue;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
      // Skip . and .. and our own pipe
      if (entry->d_name[0] == '.')
        continue;
      if (strcmp(entry->d_name, username) == 0)
        continue;

      char target_pipe[512];
      snprintf(target_pipe, sizeof(target_pipe), "%s/%s", room_path, entry->d_name);

      // Fork a child to write to each pipe (non-blocking)
      pid_t wpid = fork();
      if (wpid == 0) {
        int fd = open(target_pipe, O_WRONLY);
        if (fd >= 0) {
          write(fd, formatted, strlen(formatted));
          close(fd);
        }
        exit(0);
      }
    }
    closedir(dir);

    // Print our own message locally
    printf("%s", formatted);
  }

  // Cleanup: kill reader process
  kill(reader_pid, SIGTERM);
  waitpid(reader_pid, NULL, 0);

  return SUCCESS;
}

// (c) Custom command: countdown
// A visual countdown timer that counts down from N seconds
// Usage: countdown <seconds>
int builtin_countdown(struct command_t *command) {
  if (command->arg_count < 2 || command->args[1] == NULL) {
    fprintf(stderr, "Usage: countdown <seconds>\n");
    return SUCCESS;
  }

  int seconds = atoi(command->args[1]);
  if (seconds <= 0) {
    fprintf(stderr, "countdown: please provide a positive number of seconds\n");
    return SUCCESS;
  }

  // Forging intro
  printf("\n  Forging your sword... %d seconds\n\n", seconds);
  sleep(1);

  for (int i = seconds; i > 0; i--) {
    // Clear line and print countdown
    printf("\r\033[K");  // clear line
    int bar_width = 50;
    int filled = (int)((double)(seconds - i) / seconds * bar_width);
    int pct = (int)((double)(seconds - i) / seconds * 100);

    // handle + guard + blade + tip (no color, no emoji)
    printf("  %3d sec  <>={=", i);
    for (int j = 0; j < bar_width; j++) {
      if (j < filled)
        printf("=");
      else
        printf("-");
    }
    if (filled > 0)
      printf(">");
    else
      printf(" ");
    printf("  %d%%", pct);
    fflush(stdout);
    sleep(1);
  }

  // Final state: full sword
  printf("\r\033[K");
  printf("  Done!  <>={=");
  for (int j = 0; j < 50; j++) printf("=");
  printf(">  100%%\n");
  printf("  Your sword is ready!\n\n");

  return SUCCESS;
}

// ============================================================

int process_command(struct command_t *command) {
  int r;
  if (strcmp(command->name, "") == 0)
    return SUCCESS;

  if (strcmp(command->name, "exit") == 0)
    return EXIT;

  if (strcmp(command->name, "cd") == 0) {
    if (command->arg_count > 0) {
      r = chdir(command->args[1]);
      if (r == -1)
        printf("-%s: %s: %s\n", sysname, command->name, strerror(errno));
      return SUCCESS;
    }
  }

  // Part III: Builtin commands
  if (strcmp(command->name, "cut") == 0)
    return builtin_cut(command);

  if (strcmp(command->name, "chatroom") == 0)
    return builtin_chatroom(command);

  if (strcmp(command->name, "countdown") == 0)
    return builtin_countdown(command);

  pid_t pid = fork();
  if (pid == 0) // child
  {
    // Execute the pipeline (handles single commands too)
    exec_pipeline(command);
    exit(0); // should not reach here
  } else {
    if (!command->background) {
      waitpid(pid, NULL, 0);
    }
    return SUCCESS;
  }
}

int main() {
  // Register signal handler to reap background child processes
  signal(SIGCHLD, sigchld_handler);

  while (1) {
    struct command_t *command =
        (struct command_t *)malloc(sizeof(struct command_t));
    memset(command, 0, sizeof(struct command_t)); // set all bytes to 0

    int code;
    code = prompt(command);
    if (code == EXIT)
      break;

    code = process_command(command);
    if (code == EXIT)
      break;

    free_command(command);
  }

  printf("\n");
  return 0;
}
